package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestWikipedia {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Navya Reddy\\Downloads\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com");
		WebElement link;
		link=driver.findElement(By.name("q"));
		Thread.sleep(5000);
		link.sendKeys("facebook.com");
		link.submit();
		Thread.sleep(5000);
		//driver.quit();

	}

}
